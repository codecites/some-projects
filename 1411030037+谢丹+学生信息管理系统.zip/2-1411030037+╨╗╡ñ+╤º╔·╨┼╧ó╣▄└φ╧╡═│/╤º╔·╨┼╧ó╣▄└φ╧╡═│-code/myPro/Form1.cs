﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myPro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            skinEngine1.SkinFile = Application.StartupPath + @"\主题.ssk";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //判断用户名是否为空
            if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("用户名不能为空，请输入用户名！");
                textBox1.Focus();
                return;
            }
            //判断密码是否为空
            if (textBox2.Text.Trim() == "")
            {
                MessageBox.Show("密码不能为空，请输入密码！");
                textBox2.Focus();
                return;
            }
            //连接数据库并验证用户合法性
            SqlConnection conn = new SqlConnection(Properties.Settings.Default.systeminfo);
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("数据库无法连通的原因：" + ex.ToString());
                return;
            }
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select password,role from login where userid='" + textBox1.Text.Trim() + "'";
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
            {
                if (sdr[0].ToString().Trim() == textBox2.Text.Trim())
                {
                    classvar.userid = textBox1.Text.Trim();
                    classvar.password = sdr[0].ToString().Trim();
                    classvar.role = sdr[1].ToString().Trim();
                    if (sdr[1].ToString().Trim()=="管理员")
                    {
                            Frm_admin frm = new Frm_admin();
                            frm.Show();
                            this.Hide();
                        
                    }
                    else if (sdr[1].ToString().Trim() == "学生")
                    {
                       
                            Frm_stu frm = new Frm_stu();
                            frm.Show();
                            this.Hide();
       
                    }
                    //else {
                    //    MessageBox.Show("请选择角色！");
                    //}
                }
                else
                {
                    MessageBox.Show("密码不正确，请重新输入！");
                    textBox2.Text = "";
                    textBox2.Focus();
                }
            }
            else
            {
                MessageBox.Show("用户名不正确，请重新输入！");
                textBox1.Text = "";
                textBox1.Focus();
               
            }

        }
    }
}
