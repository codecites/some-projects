﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myPro
{
    public partial class Frm_stu : Form
    {
        public Frm_stu()
        {
            InitializeComponent();
        }

        private void 个人信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Pinfo frm = new Frm_Pinfo();
            frm.ShowDialog();
        }

        private void 密码修改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_pwd frm=new Frm_pwd();
            frm.ShowDialog();
        }

        private void 成绩查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void 分数查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void Frm_stu_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = classvar.userid;
            toolStripStatusLabel5.Text = DateTime.Now.ToLocalTime().ToString();
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select name from person where xh='" + classvar.userid + "'";
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows) {
                this.Text = "欢迎您~" + sdr[0].ToString() + "同学";
            }

        }

        private void Frm_stu_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (MessageBox.Show("确定要退出系统?", "温馨小提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            //{
            //    e.Cancel = false;
            //    Application.ExitThread();
            //}
            //else
            //{
            //    e.Cancel = true;
            //}
        }

        private void 系统首页ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void 退出系统ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.ExitThread();

        }

        private void 报表ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 查看帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = classvar.userid;
            toolStripStatusLabel5.Text = DateTime.Now.ToLocalTime().ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void 查看帮助ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string strPath = "help.CHM";
            Help.ShowHelp(this, strPath);
        }

        private void 课程查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_course frm = new Frm_course();
            frm.ShowDialog();
        }

        private void 成绩查询ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Frm_grade frm = new Frm_grade();
            frm.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
           
            
        }

        private void 注销用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
            
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Frm_Pinfo frm = new Frm_Pinfo();
            frm.ShowDialog();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Frm_pwd frm = new Frm_pwd();
            frm.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Frm_grade frm = new Frm_grade();
            frm.ShowDialog();
        }

      

       
    }
}
