﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myPro
{
    public partial class Frm_pwd : Form
    {
        public Frm_pwd()
        {
            InitializeComponent();
        }

        private void Frm_pwd_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //判断密码是否正确
            if (textBox1.Text.Trim() != classvar.password || textBox1.Text.Trim() == "")
            {
                MessageBox.Show("原密码不正确或者为空", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox1.Text = "";
                textBox1.Focus();
                return;
            }
            else
            {
                textBox2.Enabled = false;
                textBox3.Enabled = false;
            }
            //判断新密码是否符合规范
            if (textBox2.Text.Trim() != textBox3.Text.Trim() || textBox2.Text.Trim() == "")
            {
                MessageBox.Show("新密码不一致或者为空！");
                textBox2.Text = "";
                textBox3.Text = "";
                textBox2.Focus();
                return;
            }


            SqlConnection conn = new SqlConnection(Properties.Settings.Default.systeminfo);
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("连接数据错误：" + ex.ToString());
            }
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update login set password='" + textBox2.Text.Trim() + "'where userid='" + classvar.userid + "'";
            cmd.ExecuteNonQuery();
            MessageBox.Show("密码修改成功！");
            classvar.password = textBox2.Text.Trim();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
