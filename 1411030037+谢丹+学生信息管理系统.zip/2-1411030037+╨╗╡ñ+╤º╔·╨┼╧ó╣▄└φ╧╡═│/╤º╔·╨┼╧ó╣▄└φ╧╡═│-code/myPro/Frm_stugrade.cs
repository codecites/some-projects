﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace myPro
{
    public partial class Frm_stugrade : Form
    {
        public Frm_stugrade()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = true;
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
            con.Open();
            if (comboBox1.Text == "")
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from grade ", con);

                DataSet d = new DataSet();
                sda.Fill(d, "class");
                dataGridView1.DataSource = d.Tables[0];
                //kkk
                dataGridView1.Columns[0].Name = "学号";
                //dataGridView1.Columns[1]. = 155;
                //dataGridView1.Columns[2].Width = 155;
                
                
            }
            else
            {
                if (comboBox1.Text == "java")
                {
                    SqlDataAdapter sda = new SqlDataAdapter("select xh,name,java from grade ", con);

                    DataSet d = new DataSet();
                    sda.Fill(d, "class");
                    dataGridView1.DataSource = d.Tables[0];
                    dataGridView1.Columns[0].Width = 155;
                    dataGridView1.Columns[1].Width = 155;
                    dataGridView1.Columns[2].Width = 155;
                    dataGridView1.Columns[0].Name = "学号";
                    ArrayList arry = new ArrayList();
                    double sum = 0;
                    double p = 0;
                    for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                    {
                        sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                        arry.Add(d.Tables[0].Rows[j][2]);
                    }

                    p = sum / arry.Count;
                    textBox2.Text = p.ToString();
                }
                else
                {
                    if (comboBox1.Text == "C#")
                    {
                        SqlDataAdapter sda = new SqlDataAdapter("select xh,name,C# from grade ", con);

                        DataSet d = new DataSet();
                        sda.Fill(d, "class");
                        dataGridView1.DataSource = d.Tables[0];
                        dataGridView1.Columns[0].Width = 155;
                        dataGridView1.Columns[1].Width = 155;
                        dataGridView1.Columns[2].Width = 155;
                        ArrayList arry = new ArrayList();
                        double sum = 0;
                        double p = 0;
                        for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                        {
                            sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                            arry.Add(d.Tables[0].Rows[j][2]);
                        }

                        p = sum / arry.Count;
                        textBox2.Text = p.ToString();
                    }
                    else
                    {
                        if (comboBox1.Text == "jsp")
                        {
                            SqlDataAdapter sda = new SqlDataAdapter("select xh,name,jsp from grade ", con);

                            DataSet d = new DataSet();
                            sda.Fill(d, "class");
                            dataGridView1.DataSource = d.Tables[0];
                            dataGridView1.Columns[0].Width = 155;
                            dataGridView1.Columns[1].Width = 155;
                            dataGridView1.Columns[2].Width = 155;
                            ArrayList arry = new ArrayList();
                            double sum = 0;
                            double p = 0;
                            for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                            {
                                sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                                arry.Add(d.Tables[0].Rows[j][2]);
                            }

                            p = sum / arry.Count;
                            textBox2.Text = p.ToString();
                        }
                        else
                        {
                            if (comboBox1.Text == "计算机")
                            {
                                SqlDataAdapter sda = new SqlDataAdapter("select xh,name,计算机 from grade ", con);

                                DataSet d = new DataSet();
                                sda.Fill(d, "class");
                                dataGridView1.DataSource = d.Tables[0];
                                dataGridView1.Columns[0].Width = 155;
                                dataGridView1.Columns[1].Width = 155;
                                dataGridView1.Columns[2].Width = 155;
                                ArrayList arry = new ArrayList();
                                double sum = 0;
                                double p = 0;
                                for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                                {
                                    sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                                    arry.Add(d.Tables[0].Rows[j][2]);
                                }

                                p = sum / arry.Count;
                                textBox2.Text = p.ToString();
                            }
                            else
                            {
                                if (comboBox1.Text == "操作系统")
                                {
                                    SqlDataAdapter sda = new SqlDataAdapter("select xh,name,操作系统 from grade ", con);

                                    DataSet d = new DataSet();
                                    sda.Fill(d, "class");
                                    dataGridView1.DataSource = d.Tables[0];
                                    dataGridView1.Columns[0].Width = 155;
                                    dataGridView1.Columns[1].Width = 155;
                                    dataGridView1.Columns[2].Width = 155;
                                    ArrayList arry = new ArrayList();
                                    double sum = 0;
                                    double p = 0;
                                    for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                                    {
                                        sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                                        arry.Add(d.Tables[0].Rows[j][2]);
                                    }

                                    p = sum / arry.Count;
                                    textBox2.Text = p.ToString();
                                }
                                else
                                {
                                    if (comboBox1.Text == "网络应用")
                                    {
                                        SqlDataAdapter sda = new SqlDataAdapter("select xh,name,网络应用 from grade ", con);

                                        DataSet d = new DataSet();
                                        sda.Fill(d, "class");
                                        dataGridView1.DataSource = d.Tables[0];
                                        dataGridView1.Columns[0].Width = 155;
                                        dataGridView1.Columns[1].Width = 155;
                                        dataGridView1.Columns[2].Width = 155;
                                        ArrayList arry = new ArrayList();
                                        double sum = 0;
                                        double p = 0;
                                        for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                                        {
                                            sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                                            arry.Add(d.Tables[0].Rows[j][2]);
                                        }

                                        p = sum / arry.Count;
                                        textBox2.Text = p.ToString();
                                    }
                                    else
                                    {
                                        if (comboBox1.Text == "软件工程")
                                        {
                                            SqlDataAdapter sda = new SqlDataAdapter("select xh,name,软件工程 from grade ", con);

                                            DataSet d = new DataSet();
                                            sda.Fill(d, "class");
                                            dataGridView1.DataSource = d.Tables[0];
                                            dataGridView1.Columns[0].Width = 155;
                                            dataGridView1.Columns[1].Width = 155;
                                            dataGridView1.Columns[2].Width = 155;
                                            ArrayList arry = new ArrayList();
                                            double sum = 0;
                                            double p = 0;
                                            for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                                            {
                                                sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                                                arry.Add(d.Tables[0].Rows[j][2]);
                                            }

                                            p = sum / arry.Count;
                                            textBox2.Text = p.ToString();
                                        }
                                        else
                                        {
                                            SqlDataAdapter sda = new SqlDataAdapter("select xh,name,英语 from grade ", con);

                                            DataSet d = new DataSet();
                                            sda.Fill(d, "class");
                                            dataGridView1.DataSource = d.Tables[0];
                                            dataGridView1.Columns[0].Width = 155;
                                            dataGridView1.Columns[1].Width = 155;
                                            dataGridView1.Columns[2].Width = 155;
                                            ArrayList arry = new ArrayList();
                                            double sum = 0;
                                            double p = 0;
                                            for (int j = 0; j < d.Tables[0].Rows.Count; j++)
                                            {
                                                sum = sum + Convert.ToInt32(d.Tables[0].Rows[j][2]);
                                                arry.Add(d.Tables[0].Rows[j][2]);
                                            }

                                            p = sum / arry.Count;
                                            textBox2.Text = p.ToString();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }

        private void Frm_stugrade_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from grade ", con);
            DataSet d = new DataSet();
            sda.Fill(d, "class");
            dataGridView1.DataSource = d.Tables[0];
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (comboBox1.Text == "")
            {
                button2.Enabled = false;
            }
            else {
                button2.Enabled = true;
                SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
                con.Open();
                SqlCommand sql = new SqlCommand("select count(*) from grade   where " + comboBox1.Text + "<60", con);
                int i = Convert.ToInt32(sql.ExecuteScalar());
                textBox1.Text = "" + i.ToString() + "";
            }
            
        }
    }
}
