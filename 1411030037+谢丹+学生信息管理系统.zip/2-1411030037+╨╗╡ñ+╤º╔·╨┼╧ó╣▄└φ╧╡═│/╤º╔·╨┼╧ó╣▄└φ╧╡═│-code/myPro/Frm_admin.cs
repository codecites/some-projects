﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace myPro
{
    public partial class Frm_admin : Form
    {
        public Frm_admin()
        {
            InitializeComponent();
        }

        private void 学生信息管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_stuinfo frm = new Frm_stuinfo();
            frm.ShowDialog();
        }

        private void 班级分数统计ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_stugrade frm = new Frm_stugrade();
            frm.ShowDialog();
        }

        private void Frm_admin_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (MessageBox.Show("确定要退出系统?", "温馨小提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                e.Cancel = false;
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }

        }

        private void Frm_admin_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = classvar.userid;
            toolStripStatusLabel5.Text = DateTime.Now.ToLocalTime().ToString();
        }

        private void 退出系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("是否关闭当前页面？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)) == DialogResult.Yes)
            {
                Application.ExitThread();
            }
        }

        private void 上传成绩ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_updateGrade frm = new Frm_updateGrade();
            frm.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void 报表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Frm_table frm = new Frm_table();
            //frm.ShowDialog();
        }

        private void 查看帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = classvar.userid;
            toolStripStatusLabel5.Text = DateTime.Now.ToLocalTime().ToString();
        }

        private void 查看帮助ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string strPath = "help.CHM";
            Help.ShowHelp(this, strPath);
        }

        private void 学生信息管理ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Frm_stuinfo frm = new Frm_stuinfo();
            frm.ShowDialog();
        }

        private void 系统首页ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 注销用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Frm_updateGrade frm = new Frm_updateGrade();
            frm.ShowDialog();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Frm_stuinfo frm = new Frm_stuinfo();
            frm.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Frm_stugrade frm = new Frm_stugrade();
            frm.ShowDialog();
        }

        private void 成绩报表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Report1 frm = new Frm_Report1();
            frm.Show();
        }
    }
}
