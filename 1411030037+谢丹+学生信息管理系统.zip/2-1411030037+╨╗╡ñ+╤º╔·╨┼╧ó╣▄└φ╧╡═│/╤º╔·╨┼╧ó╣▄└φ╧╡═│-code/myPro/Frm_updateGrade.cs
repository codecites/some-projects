﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myPro
{
    public partial class Frm_updateGrade : Form
    {
        public Frm_updateGrade()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            if (textBox1.Text.Trim() == "java")
            {
                cmd.CommandText = "update grade set java='" + textBox4.Text.Trim() + "' where xh='"+ textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                MessageBox.Show("添加成功！");
            }
            else {
                if (textBox1.Text.Trim() == "C#")
                {
                    cmd.CommandText = "update grade set java='" + textBox4.Text.Trim() + "'where xh='" + textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("添加成功！");
                }
                else {
                    if (textBox1.Text.Trim() == "jsp")
                    {
                        cmd.CommandText = "update grade set jsp='" + textBox4.Text.Trim() + "'where xh='" + textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                        cmd.CommandType = CommandType.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("添加成功！");
                    }
                    else {
                        if (textBox1.Text.Trim() == "计算机")
                        {
                            cmd.CommandText = "update grade set 计算机='" + textBox4.Text.Trim() + "'where xh='" + textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                            cmd.CommandType = CommandType.Text;
                            cmd.Connection = con;
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("添加成功！");
                        }
                        else {
                            if (textBox1.Text.Trim() == "操作系统")
                            {
                                cmd.CommandText = "update grade set 操作系统='" + textBox4.Text.Trim() + "'where xh='" + textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                                cmd.CommandType = CommandType.Text;
                                cmd.Connection = con;
                                cmd.ExecuteNonQuery();
                                MessageBox.Show("添加成功！");
                            }
                            else {
                                if (textBox1.Text.Trim() == "网络应用")
                                {
                                    cmd.CommandText = "update grade set 网络应用='" + textBox4.Text.Trim() + "'where xh='" + textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                                    cmd.CommandType = CommandType.Text;
                                    cmd.Connection = con;
                                    cmd.ExecuteNonQuery();
                                    MessageBox.Show("添加成功！");
                                }
                                else {
                                    if (textBox1.Text.Trim() == "软件工程")
                                    {
                                        cmd.CommandText = "update grade set 软件工程='" + textBox4.Text.Trim() + "'where xh='" + textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                                        cmd.CommandType = CommandType.Text;
                                        cmd.Connection = con;
                                        cmd.ExecuteNonQuery();
                                        MessageBox.Show("添加成功！");
                                    }
                                    else {
                                        cmd.CommandText = "update grade set 英语='" + textBox4.Text.Trim() + "'where xh='" + textBox2.Text.Trim() + "'and name='" + textBox3.Text.Trim()+"'";
                                        cmd.CommandType = CommandType.Text;
                                        cmd.Connection = con;
                                        cmd.ExecuteNonQuery();
                                        MessageBox.Show("添加成功！");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            
        }

        private void Frm_updateGrade_Load(object sender, EventArgs e)
        {

        }
    }
}
