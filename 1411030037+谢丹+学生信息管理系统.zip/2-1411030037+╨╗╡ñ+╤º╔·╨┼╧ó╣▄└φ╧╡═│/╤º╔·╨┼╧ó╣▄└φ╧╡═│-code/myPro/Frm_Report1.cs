﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace myPro
{
    public partial class Frm_Report1 : Form
    {
        public Frm_Report1()
        {
            InitializeComponent();
        }

        private void Frm_Report1_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“systemInfomationDataSet4.grade”中。您可以根据需要移动或删除它。
            this.gradeTableAdapter.Fill(this.systemInfomationDataSet4.grade);

            this.reportViewer1.RefreshReport();
        }
    }
}
