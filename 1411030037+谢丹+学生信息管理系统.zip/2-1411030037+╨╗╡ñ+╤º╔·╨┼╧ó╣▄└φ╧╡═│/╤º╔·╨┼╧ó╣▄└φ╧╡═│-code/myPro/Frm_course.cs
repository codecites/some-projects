﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace myPro
{
    public partial class Frm_course : Form
    {
        public Frm_course()
        {
            InitializeComponent();
        }

        private void pictureBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //this.Validate();
            //this.pictureBindingSource.EndEdit();
            //this.tableAdapterManager.UpdateAll(this.systemInfomationDataSet);

        }

        private void classBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.classBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.systemInfomationDataSet1);

        }

        private void Frm_course_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“systemInfomationDataSet1._class”中。您可以根据需要移动或删除它。
            this.classTableAdapter.Fill(this.systemInfomationDataSet1._class);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from class  where classname like '%" + textBox1.Text.Trim() + "%'", con);
            DataSet d = new DataSet();
            sda.Fill(d, "class");
            dataGridView1.DataSource = d.Tables[0];
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].HeaderText = "课程名";
            dataGridView1.Columns[2].HeaderText = "上课时间";
            dataGridView1.Columns[3].HeaderText = "上课地点";
            dataGridView1.Columns[1].Width = 170;
            dataGridView1.Columns[2].Width = 170;
            dataGridView1.Columns[3].Width = 160;

            return;

            
        }

        private void classDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
