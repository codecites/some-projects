﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
	

namespace myPro
{
    public partial class Frm_Pinfo : Form
    {
        public Frm_Pinfo()
        {
            InitializeComponent();
        }

        private void Frm_Pinfo_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox1.Text = "";
            textBox9.Enabled = false;
            textBox4.Enabled = false;
            textBox9.Text = "";
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from person where xh=" + classvar.userid;
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
            {
                textBox1.Text = sdr[0].ToString();
                textBox2.Text = sdr[1].ToString();
                textBox3.Text = sdr[2].ToString();
                textBox4.Text = sdr[3].ToString();
                textBox5.Text = sdr[4].ToString();
                textBox6.Text = sdr[5].ToString();
                textBox7.Text = sdr[6].ToString();
                textBox8.Text = sdr[7].ToString();
                textBox9.Text = sdr[8].ToString();
                

            }
            sdr.Dispose();
            SqlCommand cme = new SqlCommand();
            cme.CommandText = "select pic from picture where xh=" + classvar.userid;
            cme.CommandType = CommandType.Text;
            cme.Connection = con;
            SqlDataReader sd = cme.ExecuteReader();
            sd.Read();
            if (sd.HasRows) {
                pictureBox1.Load("image/" + sd[0].ToString());
            }
            sd.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //openFileDialog1.Filter = "图片|*.jpg|图片|*.png";
            //if (openFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    //照片TextBox.Text = openFileDialog1.SafeFileName;
            //    pictureBox1.Load(openFileDialog1.FileName);
            //}
            if ((openFileDialog1.ShowDialog()) == DialogResult.OK) {
                string s = openFileDialog1.SafeFileName;
                SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update picture set pic='" + s+"' where xh='"+textBox1.Text.Trim()+"'" ;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                MessageBox.Show("添加成功！");
                
                cmd.Dispose();
                SqlCommand cme = new SqlCommand();
                cme.CommandText = "select pic from picture where xh=" + classvar.userid;
                cme.CommandType = CommandType.Text;
                cme.Connection = con;
                SqlDataReader sd = cme.ExecuteReader();
                sd.Read();
                if (sd.HasRows)
                {
                    pictureBox1.Load("image/" + sd[0].ToString());
                }
                sd.Dispose();
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo );
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "update person set name='" + textBox2.Text.Trim() + "',sex='" + textBox3.Text.Trim() + "',age='" + textBox5.Text.Trim() + "',home='" + textBox6.Text.Trim() + "',email='" + textBox7.Text.Trim() + "',phone='" + textBox8.Text.Trim()+"' where xh='"+textBox1.Text.Trim()+"'";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            MessageBox.Show("修改成功！");
            con.Close();
            cmd.Dispose();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

       

       
    }
}
