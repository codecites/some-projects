﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace myPro
{
    public partial class Frm_stuinfo : Form
    {
        public Frm_stuinfo()
        {
            InitializeComponent();
        }

        
        private void Frm_stuinfo_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“systemInfomationDataSet3.person”中。您可以根据需要移动或删除它。
            this.personTableAdapter.Fill(this.systemInfomationDataSet3.person);

        }

        private void emailLabel_Click(object sender, EventArgs e)
        {

        }

        SqlConnection conn = new SqlConnection(Properties.Settings.Default.systeminfo);
        SqlCommand cmd = new SqlCommand();


        private void button1_Click(object sender, EventArgs e)
        {
            //修改成绩
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandType = CommandType.Text;
            //MessageBox.Show(xuehao);
            cmd.CommandText = "update person set sex='" + sexTextBox.Text.Trim() +
                                            "',name='" + nameTextBox.Text.Trim() +
                                            "',birth='" + birthDateTimePicker.Value +
                                            "',age='" + ageTextBox.Text.Trim() +
                                            "',home='" + homeTextBox.Text.Trim() +
                                            "',email='" + emailTextBox.Text.Trim() +
                                            "',phone='" + phoneTextBox.Text.Trim() +
                                            "',major='" + majorTextBox.Text.Trim() +
                                            "' where xh='" + xhTextBox.Text.Trim() + "'";
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("修改成功！");


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.Fill(this.systemInfomationDataSet3.person);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //if(classvar.xuehao==xhTextBox.Text.Trim()){
            //    MessageBox.Show("学号为主键，不能重复！");
            //    return;
            //}
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandType = CommandType.Text;
            //MessageBox.Show(xuehao);
            cmd.CommandText = "insert into person values('" + xhTextBox.Text.Trim() +
                                            "','" + nameTextBox.Text.Trim() +
                                            "','" + sexTextBox.Text.Trim() +
                                            "','" + birthDateTimePicker.Value +
                                            "','" + ageTextBox.Text.Trim() +
                                            "','" + homeTextBox.Text.Trim() +
                                            "','" + emailTextBox.Text.Trim() +
                                            "','" + phoneTextBox.Text.Trim() +
                                            "','" + majorTextBox.Text.Trim() +
                                            "')";
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("添加成功！");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandType = CommandType.Text;
            //MessageBox.Show(xuehao);
            cmd.CommandText = "delete from person where xh='"+xhTextBox.Text.Trim()+"'";
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("删除成功！");
        }
        
        private void personDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            classvar.xuehao= personDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString(); 
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
