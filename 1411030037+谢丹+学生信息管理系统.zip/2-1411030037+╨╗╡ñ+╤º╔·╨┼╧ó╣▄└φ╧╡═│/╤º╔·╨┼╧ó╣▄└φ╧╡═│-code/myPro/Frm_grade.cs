﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace myPro
{
    public partial class Frm_grade : Form
    {
        public Frm_grade()
        {
            InitializeComponent();
        }

        private void Frm_grade_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.systeminfo);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from grade  where xh=" + classvar.userid, con);
            DataSet d = new DataSet();
            sda.Fill(d, "class");
            dataGridView1.DataSource = d.Tables[0];
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].Visible = false;


            ArrayList arry = new ArrayList();
            double sum = 0;
            double p = 0;
            for (int j = 2; j < 8; j++)
            {
                sum = sum + Convert.ToInt32(d.Tables[0].Rows[0][j]);
                arry.Add(d.Tables[0].Rows[0][j]);
            }

            p = sum / arry.Count;
            textBox2.Text = p.ToString();
            textBox1.Text = sum.ToString();
            return;
        }

        
    }
}
